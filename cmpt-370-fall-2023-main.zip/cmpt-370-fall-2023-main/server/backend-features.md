# Backend Feature Descriptions

## /

Testing endpoint

## /registerStudent

Handling student registration with database

## /registerOrg

Text

## /loginUser

Text

## /logoutUser

Text

## /getProfile

Text

## /orgProfile

Text

## /createNewProfile

Text

## /createNewApplication

Text

## /getStudentApplications

Text

## /getAllPostings

Text

## /editOrgProfile

Text

## /studentProfile

Text

## /postComment

Text

## /viewStudentProfile

Text

## /viewOrgProfile

Text

## /editStfProfile

Text

## /getAllOrgPosting

Text

## /getComments

Text

## /getUserByID

Text

## /deleteComment

Text

## /deletePosting

Text
