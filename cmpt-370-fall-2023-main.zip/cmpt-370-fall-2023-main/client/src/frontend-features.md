# Frontend Feature Descriptions

## /

The homepage

## /registerStudent

Student registration page

## /registerOrg

Text

## /login

Text

## /logout

Text

## /dashboardorg

Text

## /dashboardstd

Text

## /profileOrg

Text

## /profileStudent

Text

## /applications

Text

## /managePostings

Text

## /results/:resultId

Text

## /post/:title

Text

## /postapplication

Text

## /StudentApplications

Text

## /viewStudentProfile:profileID

Text

## /viewOrgProfile:profileID

Text

## /dashboardstd/studentpostpage/postapplication

Text

## /results/:resultId/postapplication

Text
